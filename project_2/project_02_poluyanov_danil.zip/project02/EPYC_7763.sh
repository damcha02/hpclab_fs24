#!/bin/bash



srun --constraint=EPYC_7763 --pty bash


